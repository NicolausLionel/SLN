# Evidence

Screenshots used as evidence in the Stage 2 personal logs (`../personal_log_<name>_V2.md`).

Each member has their own folder, named in pinyin so the image links work everywhere. Inside it, files use the same names:

| File | Used in | What it shows |
|---|---|---|
| `level1-2026-11-04.png` | Level 1 · 4 Nov | Evidence of the member's own contribution that day |
| `level2-2026-11-05.png` | Level 2 · 5 Nov | Evidence of the member's own contribution that day |
| `level3-2026-11-06.png` | Level 3 · 6 Nov | Evidence of the member's own contribution that day |
| `ai-use.png` | Power-up log · AI use | The AI conversation behind the AI-use entry (only for members who logged AI use) |

| Folder | Member | Log |
|---|---|---|
| `zhou-lifu/` | 周利福 | [personal_log_周利福_V2.md](../personal_log_周利福_V2.md) |
| `zeng-ruilin/` | 曾瑞琳 | [personal_log_曾瑞琳_V2.md](../personal_log_曾瑞琳_V2.md) |
| `xue-chunlan/` | 薛春兰 | [personal_log_薛春兰_V2.md](../personal_log_薛春兰_V2.md) |
| `yao-guangyao/` | 姚光耀 | [personal_log_姚光耀_V2.md](../personal_log_姚光耀_V2.md) |
| `mo-ren/` | 墨仁 | [personal_log_墨仁_V2.md](../personal_log_墨仁_V2.md) |
| `he-enqiang/` | 何恩强 | [personal_log_何恩强_V2.md](../personal_log_何恩强_V2.md) |

Some members share the same screenshot (for example, 墨仁 and 曾瑞琳 both show the Study Guide pages for Level 1), so a few files are identical copies. Each member keeps their own copy so their log never depends on someone else's folder.

## Adding new evidence

1. Put the screenshot in your own folder.
2. Name it `level<N>-<date>.png` (or `ai-use.png`). Avoid spaces and brackets in filenames, because they break image links.
3. Link it from your log with a relative path, for example `![what it shows](evidence/zhou-lifu/level1-2026-11-04.png)`.
